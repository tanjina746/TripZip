-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2020 at 05:11 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(20) NOT NULL,
  `image` varchar(255) NOT NULL,
  `Caption` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `age` int(11) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `name`, `age`, `email`) VALUES
(101, 'abul', 22, 'abul@xyz.com'),
(102, 'ali', 22, 'ali@xyz@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `image_text` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `image`, `image_text`, `timestamp`, `username`) VALUES
(2, 'Desert.jpg', 'In Quest of Knowledge is the story of Imam Muhammad ibn Idris al-Shafi‘i’s search for knowledge. The story revolves round a son whose sole mission in life is to acquire knowledge, a teacher who lovingly accepts him, and a widow who not only bears with the separation of her only son but also shares his passion for knowledge. Their innate nobility, their ability to suffer for a common cause, their intense love for the Prophet (s) and their infinite trust in Allah give them the dimensions of epic heroes.\r\n\r\nThe invaluable lesson which Imam al-Shafi‘i’s story teaches, although it may not have been his main objective, is that Allah befriends and watches over anyone who endeavours to acquire religious kn', '2020-11-29 20:30:09', ''),
(3, 'Desert.jpg', 'In Quest of Knowledge is the story of Imam Muhammad ibn Idris al-Shafi‘i’s search for knowledge. The story revolves round a son whose sole mission in life is to acquire knowledge, a teacher who lovingly accepts him, and a widow who not only bears with the separation of her only son but also shares his passion for knowledge. Their innate nobility, their ability to suffer for a common cause, their intense love for the Prophet (s) and their infinite trust in Allah give them the dimensions of epic heroes.\r\n\r\nThe invaluable lesson which Imam al-Shafi‘i’s story teaches, although it may not have been his main objective, is that Allah befriends and watches over anyone who endeavours to acquire religious kn', '2020-11-29 20:30:09', ''),
(4, 'Penguins.jpg', 'Upload Image in database using PHP MySQL', '2020-11-29 20:30:09', ''),
(5, 'Koala.jpg', '\r\nComputers don\'t lie, if it says it doesn\'t see it, then it is not there\r\n\r\nMake sure you are making it look at the right place, and if I will advise you do it manually also to confirm\r\n\r\nI also suspect it is an issue arising from using relative paths. Please make sure the path is right considering where you are currently calling the file from\r\n\r\ne.g calling include(../includes/db.php) from index.php is different from calling it from admin/index.php\r\n\r\nEDIT\r\n\r\nIf your are calling from C:\\xampp\\htdocs\\portfolio\\admin\\includes\\admin_header.php to C:\\xampp\\htdocs\\portfolio\\includes\r\n\r\nthen', '2020-11-29 20:30:09', ''),
(6, 'Tulips.jpg', '\r\nComputers don\'t lie, if it says it doesn\'t see it, then it is not there\r\n\r\nMake sure you are making it look at the right place, and if I will advise you do it manually also to confirm\r\n\r\nI also suspect it is an issue arising from using relative paths. Please make sure the path is right considering where you are currently calling the file from\r\n\r\ne.g calling include(../includes/db.php) from index.php is different from calling it from admin/index.php\r\n\r\nEDIT\r\n\r\nIf your are calling from C:\\xampp\\htdocs\\portfolio\\admin\\includes\\admin_header.php to C:\\xampp\\htdocs\\portfolio\\includes\r\n\r\nthen', '2020-11-29 20:30:09', ''),
(7, 'Tulips.jpg', '\r\nComputers don\'t lie, if it says it doesn\'t see it, then it is not there\r\n\r\nMake sure you are making it look at the right place, and if I will advise you do it manually also to confirm\r\n\r\nI also suspect it is an issue arising from using relative paths. Please make sure the path is right considering where you are currently calling the file from\r\n\r\ne.g calling include(../includes/db.php) from index.php is different from calling it from admin/index.php\r\n\r\nEDIT\r\n\r\nIf your are calling from C:\\xampp\\htdocs\\portfolio\\admin\\includes\\admin_header.php to C:\\xampp\\htdocs\\portfolio\\includes\r\n\r\nthen', '2020-11-29 20:30:09', ''),
(11, 'Jellyfish.jpg', '\r\nComputers don\'t lie, if it says it doesn\'t see it, then it is not there\r\n\r\nMake sure you are making it look at the right place, and if I will advise you do it manually also to confirm\r\n\r\nI also suspect it is an issue arising from using relative paths. Please make sure the path is right considering where you are currently calling the file from\r\n\r\ne.g calling include(../includes/db.php) from index.php is different from calling it from admin/index.php\r\n\r\nEDIT\r\n\r\nIf your are calling from C:\\xampp\\htdocs\\portfolio\\admin\\includes\\admin_header.php to C:\\xampp\\htdocs\\portfolio\\includes\r\n\r\nthen', '2020-11-29 20:30:09', ''),
(16, 'Jellyfish.jpg', '\r\nComputers don\'t lie, if it says it doesn\'t see it, then it is not there\r\n\r\nMake sure you are making it look at the right place, and if I will advise you do it manually also to confirm\r\n\r\nI also suspect it is an issue arising from using relative paths. Please make sure the path is right considering where you are currently calling the file from\r\n\r\ne.g calling include(../includes/db.php) from index.php is different from calling it from admin/index.php\r\n\r\nEDIT\r\n\r\nIf your are calling from C:\\xampp\\htdocs\\portfolio\\admin\\includes\\admin_header.php to C:\\xampp\\htdocs\\portfolio\\includes\r\n\r\nthen', '2020-11-29 20:30:09', ''),
(17, 'Chrysanthemum.jpg', ' don\'t lie, if it says it doesn\'t see it, then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arising from using relative paths. Please make sure the path is right considering where you are currently calling the file from e.g calling include(../includes/db.php) from index.php is different from calling it from admin/index.php EDIT If your are calling from C:\\xampp\\htdocs\\portfolio\\admin\\includes\\admin_header.', '2020-11-30 04:12:32', ''),
(18, 'Chrysanthemum.jpg', ' don\'t lie, if it says it doesn\'t see it, then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arising from using relative paths. Please make sure the path is right considering where you are currently calling the file from e.g calling include(../includes/db.php) from index.php is different from calling it from admin/index.php EDIT If your are calling from C:\\xampp\\htdocs\\portfolio\\admin\\includes\\admin_header.', '2020-11-30 04:14:11', ''),
(19, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:35:11', 'alu'),
(20, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:37:42', 'alu'),
(21, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:38:39', 'alu'),
(22, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:39:33', 'alu'),
(23, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:40:05', 'alu'),
(24, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:40:35', 'alu'),
(25, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:41:06', 'alu'),
(26, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:41:32', 'alu'),
(27, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:42:14', 'alu'),
(28, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:43:46', 'alu'),
(29, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:44:16', 'alu'),
(30, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:44:36', 'alu'),
(31, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:44:50', 'alu'),
(32, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:45:15', 'alu'),
(33, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:45:30', 'alu'),
(34, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:45:58', 'alu'),
(35, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:46:17', 'alu'),
(36, 'beverage-blur-cup-370018-1024x747.jpg', ' then it is not there Make sure you are making it look at the right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arisin', '2020-12-05 04:46:38', 'alu'),
(37, 'beverage-blur-cup-370018-1024x747.jpg', 'ou do it manually also to confirm I also suspect it is an issue arising from using relative paths. Please make sure the path is right considering where you are currently calling the file from e.g calling include(../includes/d', '2020-12-05 06:21:50', 'mula'),
(38, 'im.jpg', 'right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arising from using relative paths. Please make sure the path is right consid', '2020-12-05 07:15:17', 'bob'),
(39, 'Untitled3.png', 'fgbierf;roijgo;iejgeo', '2020-12-05 08:45:31', 'bob'),
(40, 'Untitled.png', 'lg;lsgnelgnmlek', '2020-12-05 08:50:49', 'bob'),
(41, 'Untitled.png', 'lg;lsgnelgnmlek', '2020-12-05 08:55:32', 'bob'),
(42, 'Untitled.png', 'lg;lsgnelgnmlek', '2020-12-05 09:56:57', 'bob'),
(43, 'Untitled.png', 'lg;lsgnelgnmlek', '2020-12-05 14:13:35', 'bob'),
(44, 'Untitled2.png', 'right place, and if I will advise you do it manually also to confirm I also suspect it is an issue arising from using relative paths. Please make sure the path ', '2020-12-05 15:23:05', 'jarin'),
(45, 'Untitled2.png', 'will watch rainbow together', '2020-12-06 04:56:39', 'jarin'),
(46, 'Untitled2.png', 'will watch rainbow together', '2020-12-06 04:58:02', 'jarin'),
(47, 'Untitled2.png', 'will watch rainbow together', '2020-12-06 04:58:58', 'jarin'),
(48, 'Untitled.png', 'grfdf fgsgg', '2020-12-06 05:00:07', 'jarin'),
(49, '', 'gkkkkk', '2020-12-06 05:03:39', 'jarin'),
(50, '', 'jjjd', '2020-12-06 05:04:59', 'jarin'),
(51, '', 'hhh', '2020-12-06 06:14:49', 'jarin'),
(52, '', '', '2020-12-07 08:49:08', 'bob'),
(53, '', '', '2020-12-07 08:49:18', 'bob'),
(54, 'WhatsApp Image 2020-12-07 at 6.43.52 PM.jpeg', 'There is no better place in which to experience the magic of the Hill Tracts than in the lively small town of Bandarban, which lies on the Sangu River, 92km from Chittagong.', '2020-12-07 14:28:59', 'bob'),
(55, 'chit2.jpg', 'Chittagong is Bangladesh\'s second-largest city and the country\'s largest port. It\'s a gritty, polluted and congested place, but as the gateway to the Chittagong Hill Tracts – one of the most beautiful and fascinating corners of the country – it\'s somewhere that many visitors pass through at some point.', '2020-12-07 14:29:33', 'bob'),
(56, 'rang.jpg', 'Rangamati is the most popular destination in the Chittagong Hill Tracts for Bangladeshi visitors, who come to enjoy the scenic splendour of Kaptai Lake, the country’s largest artificial lake, which was created in 1960 for hydroelectricity.', '2020-12-07 14:30:08', 'bob'),
(57, 'Sylhet.jpg', 'Friendly Sylhet is a divisional capital with a pronounced small-town feel, its congested streets and bustling roadside markets chipping in with requisite measures of sights, sounds and smells. The town, however, also gives off a strong underlying sense of economic prosperity.', '2020-12-07 14:30:40', 'bob'),
(58, 'rang.jpg', 'Friendly Sylhet is a divisional capital with a pronounced small-town feel, its congested streets and bustling roadside markets chipping in with requisite measures of sights, sounds and smells. The town, however, also gives off a strong underlying sense of economic prosperity.Friendly Sylhet is a divisional capital with a pronounced small-town feel, its congested streets and bustling roadside markets chipping in with requisite measures of sights, sounds and smells. The town, however, also gives off a strong underlying sense of economic prosperity.Friendly Sylhet is a divisional capital with a pronounced small-town feel, its congested streets and bustling roadside markets chipping in with requisite measures of sights, sounds and smells. The town, however, also gives off a strong underlying sense of economic prosperity.Friendly Sylhet is a divisional capital with a pronounced small-town feel, its congested streets and bustling roadside markets chipping in with requisite measures of sights, sounds and smells. The town, however, also gives off a strong underlying sense of economic prosperity.Friendly Sylhet is a divisional capital with a pronounced small-town feel, its congested streets and bustling roadside markets chipping in with requisite measures of sights, sounds and smells. The town, however, also gives off a strong underlying sense of economic prosperity.', '2020-12-07 14:31:32', 'bob');

-- --------------------------------------------------------

--
-- Table structure for table `plan`
--

CREATE TABLE `plan` (
  `planid` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `image_text` varchar(255) NOT NULL,
  `peep_num` int(10) NOT NULL,
  `budget_e` varchar(100) NOT NULL,
  `travel_f` varchar(11) NOT NULL,
  `travel_t` varchar(11) NOT NULL,
  `timestamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `plan`
--

INSERT INTO `plan` (`planid`, `image`, `image_text`, `peep_num`, `budget_e`, `travel_f`, `travel_t`, `timestamp`, `username`) VALUES
(1, 'Untitled1.png', '', 0, '', '', '', '2020-12-05 08:35:31.000000', 'bob'),
(2, 'Untitled1.png', '', 0, '', '', '', '2020-12-05 08:36:37.000000', 'bob'),
(3, 'Untitled1.png', 'muhaha', 0, '', '', '', '2020-12-05 08:45:12.000000', 'bob'),
(4, '', '8', 0, '', '', '', '2020-12-06 05:07:28.000000', 'jarin'),
(5, '', '9', 0, '', '', '', '2020-12-06 05:08:02.000000', 'jarin'),
(6, '', 'dddd', 7, '', '', '', '2020-12-06 05:09:53.000000', 'jarin'),
(7, '', 'hhgh', 7, '', '', '', '2020-12-06 05:10:39.000000', 'jarin'),
(8, 'WhatsApp Image 2020-12-05 at 1.21.54 PM (1).jpeg', 'jkjdfkjsfa', 5, '', '', '', '2020-12-06 09:55:58.000000', 'jarin'),
(9, 'WhatsApp Image 2020-12-05 at 1.21.54 PM.jpeg', 'wfgggg', 7, '', '', '', '2020-12-06 10:10:21.000000', 'jarin'),
(10, 'WhatsApp Image 2020-12-05 at 1.21.54 PM.jpeg', 'wfgggg', 7, '3434-344', '', '', '2020-12-06 10:11:14.000000', 'jarin'),
(11, '', 'ddd', 5, '555', '', '', '2020-12-06 10:17:03.000000', 'jarin'),
(12, '', 'jahah kjaka', 6, '3300-3400', 'dhaka', 'chittagong', '2020-12-06 10:20:25.000000', 'jarin'),
(13, '', 'jahah kjaka', 6, '3300-3400', 'dhaka', 'chittagong', '2020-12-06 10:22:09.000000', 'jarin'),
(14, 'beverage-blur-cup-370018-1024x747.jpg', 'jjsakjkjsjks dlldslkdldkdkl', 7, '4000', 'dhaka', 'rajshahi', '2020-12-06 12:34:42.000000', 'jarin'),
(15, 'beverage-blur-cup-370018-1024x747.jpg', 'jjsakjkjsjks dlldslkdldkdkl', 7, '4000', 'dhaka', 'rajshahi', '2020-12-06 12:41:59.000000', 'jarin'),
(16, '', '', 0, '', '', '', '2020-12-07 00:38:28.000000', 'jarin'),
(17, '', ';lfs;lfks fdsl;k;klfa\'af\'asdf', 20, '3000-4000', 'Dhaka', 'Rajshahi', '2020-12-07 14:59:47.000000', 'bob'),
(18, 'chit.jpg', 'jklak;ldak;ldasladsa\' ladsl\'ds', 7, '3000-4000', 'Dhaka', 'Rajshahi', '2020-12-07 15:00:48.000000', 'bob');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, '11', '11@gmailcom', 'c20ad4d76fe97759aa27a0c99bff6710'),
(2, '12', '12@gmail.com', 'c20ad4d76fe97759aa27a0c99bff6710'),
(3, 'asif', 'asif@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(4, 'niloy', 'niloy@gmail.com', '4bc66266b4b908b8657fad3e889e54ff'),
(5, 'nafi', 'nafi@gmail.com', '5bfb391e6148ab027d7389fed2427a86'),
(6, 'shafin', 'shafin@gmail.com', 'f76cf697cee22550e7f6cddf7539a07c'),
(7, 'alu', 'alu@gmail.com', 'b9839cf7b6959e0763df69ba8468d618'),
(8, 'mula', 'mula@gmail.com', '8a5feffca358f60191e0a95e317cf181'),
(9, 'bob', 'bob@gmail.com', '9f9d51bc70ef21ca5c14f307980a29d8'),
(10, 'jarin', 'jarin@gmail.com', 'a22f6590aececd4d295202dc6411e36a');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plan`
--
ALTER TABLE `plan`
  ADD PRIMARY KEY (`planid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `plan`
--
ALTER TABLE `plan`
  MODIFY `planid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
