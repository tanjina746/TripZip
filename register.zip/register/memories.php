<?php 
//strat the session
  session_start(); 
//check if session data are collected
  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
	  unset($_SESSION['username']);
	  unset($_SESSION['email']);
  	header("location: login.php");
  }
  ?>




<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "registration");

  // Initialize message variable
  $msg = "";

  
  $result = mysqli_query($db, "SELECT * FROM images where username='{$_SESSION['username']}' order by timestamp desc");
?>



<!DOCTYPE html>
<html>
<head>
<title>Travel Memories</title>
<style type="text/css">
 h2 {text-align: center;}
p {text-align: center;}
form {text-align: center;
	
}


*{
    margin:0;
    padding: 0;
    box-sizing: border-box;
}
.main-menu {
    display: flex;
    position: relative;
    width: 100%;
    justify-content: space-between;
    align-items: center;
}

svg.Navigation_Bar {
    display: none;
}
div#Navigation_Bar {
    display: flex;
    padding: 5px 40px;
    background: #F6F6F6;
}

.all-nav {
    position: relative;
    /* display: flex; */
    right: 40px;
}

.all-nav ul {
    display: flex;
    align-items: center;
    justify-content: center;
}

.all-nav ul li {
    list-style: none;
}

.all-nav ul li a {
    text-decoration: none;
    color: #777;
    margin: 0 20px;
    font-size: 1.2em;
}

.nav-img {
    margin-top: 80px;
}






.plan {fill: #F6F6F6;
       }

.plan {
	    height:1095px;
        width: 1000px;
		left: 100px;
		top: 108px;
		overflow: visible;
		position:absolute;
		background-color:#f6f6f6;
		padding-left:100px;
		padding-top:55px;
		padding-right:230px;
		font-family:Rubik;
    }
input[type=text] { 
	           width:100%;
	           border:1px;
			   margin:9px;
			   padding-top:22px;
			   font-size: 22px;
			   }
.head_plan {padding-left: 150px;
            font-size:42px;
            font-family: :italic;

			}
input[type=number] { width:100%;
	           border:1px;
			   margin:9px;
			   padding:8px;
			   font-size: 22px;
			   }
			   
.submit {
	     font-size: 24px;
         margin-left:0px;
		 margin-top: 20px;
		 font-family:Rubik;
		 color:#997BC6}


input[type=date] { 
	           width:100%;
	           border:1px;
			   margin:9px;
			   padding-top:22px;
			   font-size: 22px;
			   }
#img_div{
   	width: 80%;
	left:10%;
    bottom:10%;
   	padding: 5px;
   	margin: 15px auto;
   	border: 1px solid #cbcbcb;
   }

   #logo {
		position: absolute;
		width: 106px;
		height: 69px;
		left: 50px;
		top: 10px;
		overflow: visible;
	}




	#img_div:after{
   	content: "";
   	display: block;
   	clear: both;
   }
   img{
   	float: left;
   	margin: 5px;
   	width: 300px;
   	height: 140px;
   }


   textarea {
/*left:100px;*/	   
  margin-left:0px;  
  width: 500px;
  height: 70px;
  font-size: 20px; 
  padding: 30px 5px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

</style>
</head>

<body>

<div id="Navigation_Bar">
	<div class="main-menu">
		<svg class="Navigation_Bar">
			<rect id="Navigation_Bar"  width="1920" height="87">
			</rect>
		</svg>
		
		<div class="logo">
			<img id="logo" src="https://i.ibb.co/QN4KDNQ/Component-1-32.png" >
		</div>
	
			
	
		<div class="all-nav">
			<ul>
			<li><a href="http://localhost/register/index.php">Home</a></li>
				<li><a href="#">Mingle</a></li>
				<li><a href="http://localhost/register/cms.php">Travel Wall</a></li>
				<li><a href="http://localhost/register/showplan.php">Travel Plan</a></li>
				<li><a href="http://localhost/register/memories.php">Travel Memories</a></li>
			</ul>
		</div>
	</div>

	<div class="nav-img">
	<!--<img id="NoPath_-_Copy_14" src="NoPath_-_Copy_14.png">-->
	</div>
</div>



<br>

<?php  if (isset($_SESSION['username'])) : ?>
    	<p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
		<p>Hi <?php echo $_SESSION['username']?>! what would be your next exploration? </p>
    <?php endif ?>

<br>

<form method="POST" action="cms.php" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">
  	<div>
  	  <input type="file" name="image">
  	</div>
  	<div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="4" 
      	name="image_text" 
      	placeholder="Say something about this image..."></textarea>
  	</div>
  	<div>
  		<button type="submit" name="upload">POST</button>
  	</div>
  </form>









<div id="content">

  <?php
    while ($row = mysqli_fetch_array($result)) {
		
		echo "<div id='img_div'>";
		echo "<p>"  .$row['username'].' on '.$row['timestamp']."</p>";
		//echo "<p>".$row['timestamp']."</p>";
      	echo "<img src='images/".$row['image']."' >";
		  //echo "<p>" .'Posted by ' .$row['username']."</p>"; 
		  echo "<p>".$row['image_text']."</p>";
		  
          
      echo "</div>";
    }
  ?>


</div>
</body>
</html>