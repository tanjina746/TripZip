<?php 
//strat the session
  session_start(); 
//check if session data are collected
  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
	  unset($_SESSION['username']);
	  unset($_SESSION['email']);
  	header("location: login.php");
  }
  ?>



<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "registration");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
	  // Get text
	  //Number of people
/*Type of Travel
Budget estimate
Travel From:
Travel To:
Start Date
End Date*/
	  $image_text = mysqli_real_escape_string($db, $_POST['image_text']);
	  $peep_num = mysqli_real_escape_string($db, $_POST['peep_num']);
	  $budget_e= mysqli_real_escape_string($db, $_POST['budget_e']);
	  $travel_f= mysqli_real_escape_string($db, $_POST['travel_f']);
	  $travel_t= mysqli_real_escape_string($db, $_POST['travel_t']);
	//  $start_d= mysqli_real_escape_string($db, $_POST['start_d']);
	//  $end_d= mysqli_real_escape_string($db, $_POST['end_d']);

  	// image file directory
  	$target = "place_image/".basename($image);

  	$sql = "INSERT INTO plan (image, image_text,peep_num,budget_e,travel_f,travel_t,timestamp,username)
	   VALUES ('$image','$image_text','$peep_num','$budget_e','$travel_f','$travel_t',NOW(), '{$_SESSION['username']}')";
//	$sql = mysql_query("INSERT INTO images (image, image_text, timestamp,username) VALUES('','$image','$image_text',NOW(),'{$_SESSION['username']}')");  
	  // execute query
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  $result = mysqli_query($db, "SELECT * FROM plan order by timestamp desc");
?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create a Plan</title>
<style type="text/css">
* {
		margin: 0;
		padding: 0;
		box-sizing: border-box;
		border: none;
	}

	#Navigation_Bar {
		fill: #F6F6F6;
	}
	.Navigation_Bar {
		position: absolute;
		overflow: visible;
		width: 1350px;
		height: 87px;
		left: 0px;
		top: 0px;/* style inputs ash color content in nevigation bar */
	}
	#logo {
		position: absolute;
		width: 106px;
		height: 69px;
		left: 50px;
		top: 10px;
		overflow: visible;
	}/* tripmate logo */


	#NoPath_-_Copy_14 {
		position: absolute;
		width: 52px;
		height: 52px;
		left: 1270px;
		top: 19px;
		overflow: visible;
	}/* profile image right side */
	#All_nav {
		position: absolute;
		width: 730px;
		height: 24px;
		left: 832px;
		top: 32px;
		overflow: visible;
	}/* button space id  */
	#Home {
		left: 0px;
		top: 0px;
		position: absolute;
		overflow: visible;
		width: 56px;
		text-align: left;
		font-family: Rubik;
		font-size: 20px;
		color: #000000;
	}/* home button */
	#Mingle {
		left: 122px;
		top: 0px;
		position: absolute;
		overflow: visible;
		width: 62px;
		text-align: left;
		font-family: Rubik;
		font-size: 20px;
		color: #000000;
	}/* mingle button */
	#Travel_Wall {
		left: 250px;
		top: 0px;
		position: absolute;
		overflow: visible;
		width: 97px;
		text-align: left;
		font-family: Rubik;
		font-size: 20px;
		color: #997BC6;
	}/* travel wall button */
	#Travel_plan {
		left: 413px;
		top: 0px;
		position: absolute;
		overflow: visible;
		width: 101px;
		text-align: left;
		font-family: Rubik;
		font-size: 20px;
		color: #000000;
	}/* travel plan button */
	#Travel_Memories {
		left: 580px;
		top: 0px;
		position: absolute;
		overflow: visible;
		width: 151px;
		text-align: left;
		font-family: Rubik;
		font-size: 20px;
		color: #000000;
	}/* travel memories button */
	/* style inputs nevigation */


.plan {fill: #F6F6F6;
       }

.plan {
	    height:1095px;
        width: 1000px;
		left: 200px;
		top: 140px;
		bottom:0px;
		overflow: visible;
		position:absolute;
		background-color:#f6f6f6;
		padding-left:230px;
		padding-top:100px;
		padding-right:230px;
		font-family:Rubik;
    }/* hole plan content  */

.head_plan {padding-left: 150px;
            font-size:42px;
            font-family: :italic;

			}/* crean plans  */
input[type=number] { width:100%;
	           border:1px;
			   margin:9px;
			   padding:8px;
			   font-size: 22px;
			   }/* tif you need any number otherwise dont use this  */
			   
.submit {
	     font-size: 24px;
         margin-left:0px;
		 margin-top: 20px;
		 font-family:Rubik;
		 color:#997BC6}
/* submit button */

input[type=date] { 
	           width:100%;
	           border:1px;
			   margin:9px;
			   padding-top:22px;
			   font-size: 22px;
			   }

textarea {
  width: 100%;
  height: 50px;
  font-size: 20px; 
  padding: 30px px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

/*tanjinapur code */


*{
    margin:0;
    padding: 0;
    box-sizing: border-box;
}
.main-menu {
    display: flex;
    position: relative;
    width: 100%;
    justify-content: space-between;
    align-items: center;
}

svg.Navigation_Bar {
    display: none;
}
div#Navigation_Bar {
    display: flex;
    padding: 5px 40px;
    background: #F6F6F6;
}

.all-nav {
    position: relative;
    /* display: flex; */
    right: 40px;
}

.all-nav ul {
    display: flex;
    align-items: center;
    justify-content: center;
}

.all-nav ul li {
    list-style: none;
}

.all-nav ul li a {
    text-decoration: none;
    color: #777;
    margin: 0 20px;
    font-size: 1.2em;
}

.nav-img {
    margin-top: 80px;
}



/*
   #content{
   	width: 50%;
   	margin: 20px auto;
   	border: 1px solid #cbcbcb;
   }
   form{
   	width: 50%;
   	margin: 20px auto;
   }
   form div{
   	margin-top: 5px;
   }
   */ 
   #img_div{
   	width: 80%;
   	padding: 5px;
   	margin: 15px auto;
   	border: 1px solid #cbcbcb;
   }
   #img_div:after{
   	content: "";
   	display: block;
   	clear: both;
   }
   img{
   	float: left;
   	margin: 5px;
   	width: 300px;
   	height: 140px;
   }
  
</style>
</head>

<body>

<div id="Navigation_Bar">
	<div class="main-menu">
		<svg class="Navigation_Bar">
			<rect id="Navigation_Bar"  width="1920" height="87">
			</rect>
		</svg>
		
		<div class="logo">
			<img id="logo" src="https://i.ibb.co/QN4KDNQ/Component-1-32.png" >
		</div>
	
			
	
		<div class="all-nav">
			<ul>
			<li><a href="http://localhost/register/index.php">Home</a></li>
				<li><a href="#">Mingle</a></li>
				<li><a href="http://localhost/register/cms.php">Travel Wall</a></li>
				<li><a href="http://localhost/register/showplan.php">Travel Plan</a></li>
				<li><a href="http://localhost/register/memories.php">Travel Memories</a></li>
			</ul>
		</div>
	</div>

	<div class="nav-img">
	<!--<img id="NoPath_-_Copy_14" src="NoPath_-_Copy_14.png">-->
	</div>
</div>



<!--

<div id="Navigation_Bar">
	<svg class="Navigation_Bar">
		<rect id="Navigation_Bar"  width="1350" height="87">
		</rect>
/* hole ash bar in nevigation part   */
	</svg>
	<div class="logo">
		<img id="logo" src="https://i.ibb.co/QN4KDNQ/Component-1-32.png" >
	</div>
	<img id="NoPath_-_Copy_14" src="NoPath_-_Copy_14.png">
	<div id="All_nav">
             
			 <div>
			
			<button id="Home">   Home  </button>
			
			</div>


			<button id="Mingle">Mingle</button>


			<button id="Travel_Wall">Travel Wall</button>


			<button id="Travel_plan">Travel plan</button>


			<button id="Travel_Memories">Travel Memories</button>

	</div>
    </div>
	

</div>

-->
	<div class="plan" width="873" height="1095">
	<h2 class="head_plan"> Create a Plan </h2>


	<form method="POST" action="plan.php" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">
  	<div>
  	  <input type="file" name="image">
  	</div>
  	<div>
      <textarea 
      	id="text" 
      	cols="40" 
		font="20"  
      	rows="4"   
      	name="image_text" 
      	placeholder="Say something about this image..."></textarea>
  	</div>
      <div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="1" 
      	name="peep_num" 
      	placeholder="Number of people expected to join"></textarea>
  	</div>

	  <div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="1" 
      	name="budget_e" 
      	placeholder="Esteeemated budget"></textarea>
  	</div>

	  <div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="1" 
      	name="travel_f" 
      	placeholder="travel From"></textarea>
  	</div>

	  <div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="1" 
      	name="travel_t" 
      	placeholder="Travel to"></textarea>
  	</div>

<!--	  
	  <div>

  	  <label>Tour strats at </label>
  	  
		<input type="date" name="date" value="<?php echo $start_d; ?>">
  	</div>
  	

	  <div>
      <textarea 
      	id="date" 
      	cols="40" 
      	rows="1" 
      	name="end_d" 
      	placeholder="Tour Starts at "></textarea>
  	</div>

	-->  


  	<div>
  		<button type="submit" button class= "submit" name="upload">POST</button>
  	</div>
  </form>

</body>
</html>